const workspace = document.getElementById('workspace');
const svgLayer = document.getElementById('svg-layer');
const statusBar = document.getElementById('status-bar');
const geneticsPopup = document.getElementById('genetics-popup');
const autoTraitsContainer = document.getElementById('auto-traits-container');
const sexGenesContainer = document.getElementById('sex-genes-container');

const GRID_SIZE = 40; 

let nodes = {};
let marriages = [];
let childrenLinks = [];
let nodeIdCounter = 0;
let marriageIdCounter = 0;

let selectedNodeId = null;
let currentMode = 'idle'; 
let actionQueue = []; 
let targetNodeId = null;

let isDragging = false;
let dragTarget = null;
let dragOffsetX = 0;
let dragOffsetY = 0;

// Variável temporária para gerenciar características autossômicas no popup antes de salvar
let tempAutoTraits = [];

function updateStatus(text, isAlert = false) {
    statusBar.innerText = text;
    if (isAlert) statusBar.classList.add('status-alert');
    else statusBar.classList.remove('status-alert');
}

function setMode(mode) {
    document.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
    actionQueue = [];
    closeGenetics();
    
    if (currentMode === mode) {
        currentMode = 'idle';
        updateStatus("Modo: Livre (Arraste as peças)");
        return;
    }

    currentMode = mode;
    if (mode === 'marriage') {
        document.getElementById('btn-marriage').classList.add('active');
        updateStatus("Modo Casamento: Clique no primeiro cônjuge.", true);
    } else if (mode === 'child') {
        document.getElementById('btn-child').classList.add('active');
        updateStatus("Modo Filho: Clique no Pai.", true);
    } else if (mode === 'genetics') {
        document.getElementById('btn-genetics').classList.add('active');
        updateStatus("Modo Edição: Clique em um indivíduo para editar dados.", true);
    }
}

function snap(val) {
    return Math.round(val / GRID_SIZE) * GRID_SIZE;
}

function addNode(type) {
    const id = 'node_' + nodeIdCounter++;
    const node = document.createElement('div');
    node.id = id;
    node.className = `node ${type}`;
    
    node.style.left = snap(160) + 'px';
    node.style.top = snap(80) + 'px';
    
    node.addEventListener('mousedown', startDrag);
    node.addEventListener('click', (e) => handleNodeClick(e, id));
    
    workspace.appendChild(node);
    
    // Novo modelo de dados do indivíduo
    nodes[id] = { 
        id, type, element: node, 
        name: '', showName: false,
        desc: '', showDesc: false,
        autosomal: [], 
        sexAlleles: ['', ''], 
        showSex: false 
    };
    selectNode(id);
    
    if(currentMode !== 'genetics') setMode('idle');
}

function handleNodeClick(e, id) {
    e.stopPropagation();

    if (currentMode === 'idle') {
        selectNode(id);
        return;
    }
    
    if (currentMode === 'genetics') {
        targetNodeId = id;
        selectNode(id);
        showGeneticsPopup(id);
        return;
    }

    if (currentMode === 'marriage') {
        if (!actionQueue.includes(id)) actionQueue.push(id);
        if (actionQueue.length === 1) {
            updateStatus("Modo Casamento: Clique no primeiro cônjuge.", true);
        } else if (actionQueue.length === 2) {
            marriages.push({ id: 'm_' + marriageIdCounter++, p1: actionQueue[0], p2: actionQueue[1] });
            drawConnections();
            setMode('idle'); 
        }
    }

    if (currentMode === 'child') {
        if (!actionQueue.includes(id)) actionQueue.push(id);
        if (actionQueue.length === 1) {
            updateStatus("Modo Filho: Clique na Mãe (segundo cônjuge).", true);
        } else if (actionQueue.length === 2) {
            updateStatus("Modo Filho: Agora clique no indivíduo que será o Filho.", true);
        } else if (actionQueue.length === 3) {
            const p1 = actionQueue[0];
            const p2 = actionQueue[1];
            const childId = actionQueue[2];
            
            const marriage = marriages.find(m => 
                (m.p1 === p1 && m.p2 === p2) || (m.p1 === p2 && m.p2 === p1)
            );

            if (marriage) {
                childrenLinks.push({ marriageId: marriage.id, childId: childId });
                drawConnections();
            } else {
                alert("Esses dois indivíduos não possuem um casamento! Crie o casamento primeiro.");
            }
            setMode('idle');
        }
    }
}

// ------ GERENCIAMENTO DO POPUP ------
function showGeneticsPopup(id) {
    const node = nodes[id];
    const el = node.element;
    const rect = el.getBoundingClientRect();
    const wsRect = workspace.getBoundingClientRect();

    geneticsPopup.style.left = (rect.right - wsRect.left + 20) + 'px';
    geneticsPopup.style.top = (rect.top - wsRect.top - 10) + 'px';

    // Textos base
    document.getElementById('name-input').value = node.name;
    document.getElementById('name-cb').checked = node.showName;
    document.getElementById('desc-input').value = node.desc;
    document.getElementById('desc-cb').checked = node.showDesc;

    // Autossômicos
    tempAutoTraits = [...node.autosomal];
    renderAutoTraitsInPopup();

    // Sexuais e Checkbox de exibição forçada
    sexGenesContainer.innerHTML = '';
    const sexTitle = document.getElementById('sex-title');
    const sexCbLabel = document.getElementById('sex-cb-label');
    
    if (node.type === 'unknown') {
        sexTitle.style.display = 'none';
        sexGenesContainer.style.display = 'none';
        sexCbLabel.style.display = 'none';
    } else {
        sexTitle.style.display = 'block';
        sexGenesContainer.style.display = 'block';
        sexCbLabel.style.display = 'flex';
        
        document.getElementById('sex-cb').checked = node.showSex;

        let label1 = 'X';
        let label2 = node.type === 'male' ? 'Y' : 'X';
        
        sexGenesContainer.innerHTML = `
            <div class="sex-input-group">
                ${label1}<sup><input type="text" id="sex-al1" value="${node.sexAlleles[0]}" placeholder="_"></sup>
                &nbsp;
                ${label2}<sup><input type="text" id="sex-al2" value="${node.sexAlleles[1]}" placeholder="_"></sup>
            </div>
        `;
    }

    geneticsPopup.classList.remove('hidden');
}

function closeGenetics() {
    geneticsPopup.classList.add('hidden');
    targetNodeId = null;
}

// --- Autossômico Dinâmico ---
function addAutosomalField() {
    const type = document.getElementById('auto-type-select').value;
    let html = '';
    let traitId = Date.now(); // ID único para controle

    if (type === 'rec') {
        html = `Letra: <input type="text" id="t_${traitId}" placeholder="a" style="width: 40px;" oninput="this.value=this.value.toLowerCase().slice(0,1)"> (Fica: aa)`;
    } else if (type === 'dom') {
        html = `
            Letra: <input type="text" id="t_${traitId}_let" placeholder="A" style="width: 30px;" oninput="this.value=this.value.toUpperCase().slice(0,1)">
            <select id="t_${traitId}_zig">
                <option value="homo">Homozigoto</option>
                <option value="hetero">Heterozigoto</option>
            </select>
        `;
    } else if (type === 'codom') {
        html = `Base: <input type="text" id="t_${traitId}_base" placeholder="I" style="width:30px;">
                Al 1: <input type="text" id="t_${traitId}_al1" placeholder="A" style="width:30px;">
                Al 2: <input type="text" id="t_${traitId}_al2" placeholder="B" style="width:30px;">`;
    }

    const div = document.createElement('div');
    div.className = 'auto-trait-row';
    div.innerHTML = `
        <div style="flex:1;">${html}</div>
        <button class="btn-remove" onclick="removeAutoTraitInPopup(this, '${type}', ${traitId})">X</button>
    `;
    div.dataset.type = type;
    div.dataset.tid = traitId;

    autoTraitsContainer.appendChild(div);
}

function renderAutoTraitsInPopup() {
    autoTraitsContainer.innerHTML = '';
    tempAutoTraits.forEach((trait, index) => {
        const div = document.createElement('div');
        div.className = 'auto-trait-row';
        let visualTrait = trait.replace(/\^([^\s]+)/g, "<sup>$1</sup>");
        div.innerHTML = `
            <span style="flex:1; font-weight:bold; color:#c0392b;">${visualTrait}</span>
            <button class="btn-remove" onclick="removeSavedAutoTrait(${index})">X</button>
        `;
        autoTraitsContainer.appendChild(div);
    });
}

function removeAutoTraitInPopup(btn) {
    btn.parentElement.remove();
}
function removeSavedAutoTrait(index) {
    tempAutoTraits.splice(index, 1);
    renderAutoTraitsInPopup();
}

// --- Salvar e Renderizar no Heredograma ---
function saveGenetics() {
    if (!targetNodeId) return;
    const node = nodes[targetNodeId];

    // Salvar Nome/Desc
    node.name = document.getElementById('name-input').value.trim();
    node.showName = document.getElementById('name-cb').checked;
    node.desc = document.getElementById('desc-input').value.trim();
    node.showDesc = document.getElementById('desc-cb').checked;

    // Ler novos campos autossômicos gerados
    const newRows = autoTraitsContainer.querySelectorAll('.auto-trait-row[data-type]');
    newRows.forEach(row => {
        const t = row.dataset.type;
        const tid = row.dataset.tid;
        let result = "";

        if (t === 'rec') {
            const letter = document.getElementById(`t_${tid}`).value || 'a';
            result = letter + letter;
        } else if (t === 'dom') {
            const letter = document.getElementById(`t_${tid}_let`).value || 'A';
            const zig = document.getElementById(`t_${tid}_zig`).value;
            result = zig === 'homo' ? letter + letter : letter + letter.toLowerCase();
        } else if (t === 'codom') {
            const baseInput = document.getElementById(`t_${tid}_base`).value.trim();
            const al1 = document.getElementById(`t_${tid}_al1`).value.trim();
            const al2 = document.getElementById(`t_${tid}_al2`).value.trim();
            
            // Lógica ajustada: se tudo estiver vazio, não adiciona nada.
            if (baseInput === "" && al1 === "" && al2 === "") {
                result = "";
            } else {
                const base = baseInput !== "" ? baseInput : "I";
                // Só coloca o "^" se o alelo tiver sido preenchido
                let p1 = al1 !== "" ? `${base}^${al1}` : base;
                let p2 = al2 !== "" ? `${base}^${al2}` : base;
                result = `${p1} ${p2}`;
            }
        }
        if(result) tempAutoTraits.push(result);
    });
    node.autosomal = [...tempAutoTraits];

    // Salvar Sexual e Checkbox
    if (node.type !== 'unknown') {
        const al1 = document.getElementById('sex-al1').value.trim();
        const al2 = document.getElementById('sex-al2').value.trim();
        node.sexAlleles = [al1, al2];
        node.showSex = document.getElementById('sex-cb').checked;
    }

    renderLabelsOnNode(targetNodeId);
    closeGenetics();
}

// Constrói os textos em volta da figura
function renderLabelsOnNode(id) {
    const node = nodes[id];
    const el = node.element;
    
    // Limpa labels antigos
    el.querySelectorAll('.label-container').forEach(e => e.remove());

    // 1. TOP LABEL (Autossômicos)
    if (node.autosomal.length > 0) {
        const topDiv = document.createElement('div');
        topDiv.className = 'label-container label-top';
        let htmlTraits = node.autosomal.map(t => t.replace(/\^([^\s]+)/g, "<sup>$1</sup>")).join(', ');
        topDiv.innerHTML = htmlTraits;
        el.appendChild(topDiv);
    }

    // 2. BOTTOM LABEL (Sexo e Nome)
    if (node.type !== 'unknown' || node.name) {
        const botDiv = document.createElement('div');
        botDiv.className = 'label-container label-bottom';
        
        // Sexual (Verifica se há genes OU se a checkbox está marcada)
        if (node.type !== 'unknown' && (node.sexAlleles[0] || node.sexAlleles[1] || node.showSex)) {
            let s1 = 'X';
            let s2 = node.type === 'male' ? 'Y' : 'X';
            let sup1 = node.sexAlleles[0] ? `<sup>${node.sexAlleles[0]}</sup>` : '';
            let sup2 = node.sexAlleles[1] ? `<sup>${node.sexAlleles[1]}</sup>` : '';
            botDiv.innerHTML += `<div class="sex-text">${s1}${sup1}${s2}${sup2}</div>`;
        }
        
        // Nome
        if (node.name) {
            let nameClass = node.showName ? "name-text" : "name-text hover-only";
            botDiv.innerHTML += `<div class="${nameClass}">${node.name}</div>`;
        }
        el.appendChild(botDiv);
    }

    // 3. RIGHT LABEL (Descrição)
    if (node.desc) {
        const rightDiv = document.createElement('div');
        let rightClass = node.showDesc ? "label-container label-right" : "label-container label-right hover-only";
        rightDiv.className = rightClass;
        rightDiv.innerText = node.desc;
        el.appendChild(rightDiv);
    }
}
// ------------------------------------

function selectNode(id) {
    Object.values(nodes).forEach(n => n.element.classList.remove('selected'));
    selectedNodeId = id;
    if (id) document.getElementById(id).classList.add('selected');
}

workspace.addEventListener('mousedown', (e) => {
    if (e.target === workspace || e.target === svgLayer) {
        selectNode(null);
        closeGenetics();
    }
});

function startDrag(e) {
    if (currentMode !== 'idle') return;
    isDragging = true;
    dragTarget = e.target;
    
    const rect = dragTarget.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;
    
    selectNode(dragTarget.id);
    closeGenetics(); 
}

document.addEventListener('mousemove', (e) => {
    if (!isDragging || !dragTarget) return;
    const wsRect = workspace.getBoundingClientRect();
    let rawX = e.clientX - wsRect.left - dragOffsetX;
    let rawY = e.clientY - wsRect.top - dragOffsetY;
    
    dragTarget.style.left = snap(rawX) + 'px';
    dragTarget.style.top = snap(rawY) + 'px';
    
    drawConnections();
});

document.addEventListener('mouseup', () => {
    isDragging = false;
    dragTarget = null;
});

function drawConnections() {
    svgLayer.innerHTML = ''; 
    const wsRect = workspace.getBoundingClientRect();

    marriages.forEach(m => {
        const el1 = document.getElementById(m.p1);
        const el2 = document.getElementById(m.p2);
        if (!el1 || !el2) return;

        const r1 = el1.getBoundingClientRect();
        const r2 = el2.getBoundingClientRect();

        const x1 = (r1.left - wsRect.left) + (r1.width / 2);
        const y1 = (r1.top - wsRect.top) + (r1.height / 2);
        const x2 = (r2.left - wsRect.left) + (r2.width / 2);
        const y2 = (r2.top - wsRect.top) + (r2.height / 2);

        createSVGLine(x1, y1, x2, y2);

        const mChildren = childrenLinks.filter(c => c.marriageId === m.id);
        
        if (mChildren.length > 0) {
            const midX = (x1 + x2) / 2;
            const midY = (y1 + y2) / 2;
            const sibDropY = midY + 40; 

            createSVGLine(midX, midY, midX, sibDropY);

            mChildren.forEach(c => {
                const childEl = document.getElementById(c.childId);
                if (!childEl) return;
                const cr = childEl.getBoundingClientRect();
                
                const cx = (cr.left - wsRect.left) + (cr.width / 2);
                const cy = (cr.top - wsRect.top); 

                createSVGLine(midX, sibDropY, cx, sibDropY);
                createSVGLine(cx, sibDropY, cx, cy);
            });
        }
    });
}

function createSVGLine(x1, y1, x2, y2) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1);
    line.setAttribute('y1', y1);
    line.setAttribute('x2', x2);
    line.setAttribute('y2', y2);
    svgLayer.appendChild(line);
}

function toggleProperty(prop) {
    if (!selectedNodeId) return alert('Selecione um indivíduo primeiro.');
    document.getElementById(selectedNodeId).classList.toggle(prop);
}

function deleteSelected() {
    if (!selectedNodeId) return;
    document.getElementById(selectedNodeId).remove();
    delete nodes[selectedNodeId];
    
    marriages = marriages.filter(m => m.p1 !== selectedNodeId && m.p2 !== selectedNodeId);
    childrenLinks = childrenLinks.filter(c => c.childId !== selectedNodeId);
    
    selectedNodeId = null;
    closeGenetics();
    drawConnections();
}

function clearWorkspace() {
    if(confirm('Tem certeza que deseja apagar tudo?')) {
        Object.values(nodes).forEach(n => n.element.remove());
        nodes = {}; marriages = []; childrenLinks = [];
        drawConnections();
        closeGenetics();
    }
}

function exportToPDF() {
    selectNode(null); 
    closeGenetics();
    workspace.style.backgroundImage = 'none'; 
    
    const opt = {
        margin: 10,
        filename: 'heredograma_pro.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };

    html2pdf().set(opt).from(workspace).save().then(() => {
        workspace.style.backgroundImage = 'linear-gradient(#ececec 1px, transparent 1px), linear-gradient(90deg, #ececec 1px, transparent 1px)';
    });
}